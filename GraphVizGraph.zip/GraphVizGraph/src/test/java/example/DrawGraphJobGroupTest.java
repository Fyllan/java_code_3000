package example;

import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.junit.Test;

import java.util.List;
import java.util.function.Function;

import static org.junit.Assert.*;

public class DrawGraphJobGroupTest {

    @Test
    public void getGroupDeclaration() {
        Function<String,String> toString=a->a;
        var j1=getGraph();
        var j2=getGraph();
        var j3=getGraph();
        var j4=getGraph();
        JobnetCluster<String> c1=new JobnetCluster<>(j1,"first",1250);
        JobnetCluster<String> c2=new JobnetCluster<>(j2,"second",7230);
        JobnetCluster<String> c3=new JobnetCluster<>(j3,"third",12650);
        JobnetCluster<String> c4=new JobnetCluster<>(j4,"forth",22750);

        DrawGraphJobGroup<String> d1=new DrawGraphJobGroup<>(List.of(c1,c2,c3),0,toString);
        DrawGraphJobGroup<String> d2=new DrawGraphJobGroup<>(List.of(c4),1,toString);

        d1.getGroupDeclaration().forEach(System.out::println);
        d2.getGroupDeclaration().forEach(System.out::println);

    }
    public Graph<String,LabeledEdge> getGraph(){
        Graph<String,LabeledEdge> j1=new DefaultDirectedGraph<>(LabeledEdge.class);
        j1.addVertex("a");
        j1.addVertex("b");
        j1.addVertex("c");
        j1.addEdge("a","b",new LabeledEdge("seq"));
        j1.addEdge("b","c",new LabeledEdge("seq"));
        return j1;
    }
}