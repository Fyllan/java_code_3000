package example;

import org.jgrapht.graph.DefaultEdge;

public class LabeledEdge extends DefaultEdge {
    public String label;

    public LabeledEdge(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
