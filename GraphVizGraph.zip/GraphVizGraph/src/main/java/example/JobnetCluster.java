package example;

import org.jgrapht.Graph;

public class JobnetCluster <T>{
    public Graph<T,LabeledEdge> jobnetGraph;
    public String name;
    public int timelineLocation;

    public JobnetCluster(Graph<T, LabeledEdge> jobnetGraph, String name, int timelineLocation) {
        this.jobnetGraph = jobnetGraph;
        this.name = name;
        this.timelineLocation = timelineLocation;
    }
}
