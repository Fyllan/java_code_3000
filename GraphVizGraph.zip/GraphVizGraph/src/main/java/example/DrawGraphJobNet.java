package example;

import org.apache.commons.lang3.tuple.Pair;
import org.jgrapht.Graph;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class DrawGraphJobNet<T> {
    Graph<T,LabeledEdge> jobnetGraph;
    String name;
    int timelineLocation;
    Function<T,String> toString;

    public DrawGraphJobNet(Graph<T, LabeledEdge> jobnetGraph, String name, int timelineLocation, Function<T, String> toString) {
        this.jobnetGraph = jobnetGraph;
        this.name = name;
        this.timelineLocation = timelineLocation;
        this.toString = toString;
    }

    public List<String> getClusterDeclariation(){
        List<String> declaration=new ArrayList<>();
        declaration.add("subgraph cluster_jn_"+name+"_"+timelineLocation);

        declaration.add("{");
        declaration.add("style=\"rounded,dashed\"");
        //Node declaration
        for( var v:jobnetGraph.vertexSet()){
            declaration.add(getName(v)+ String.format("[label=\"%s\"]",toString.apply(v)));
        }
        for (var e:jobnetGraph.edgeSet()){
            var from=jobnetGraph.getEdgeSource(e);
            var to=jobnetGraph.getEdgeTarget(e);
            declaration.add(String.format("%s -> %s [label=\"%s\"]",getName(from),getName(to),e.toString()));
        }
        declaration.add("}");
        return declaration;
    }
    private String getName(T v){
        return "el"+toString.apply(v)+"_"+timelineLocation;
    }

}
