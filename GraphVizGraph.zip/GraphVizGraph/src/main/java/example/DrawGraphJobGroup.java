package example;

import org.jgrapht.Graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class DrawGraphJobGroup<T> {
    List<JobnetCluster<T>> cluster=new ArrayList<>();
    int id;
    Function<T,String> toString;

    public DrawGraphJobGroup(List<JobnetCluster<T>> cluster, int id, Function<T, String> toString) {
        this.cluster = cluster;
        this.id = id;
        this.toString = toString;
    }

    public List<String> getGroupDeclaration(){
        List<String> declaration=new ArrayList<>();
        declaration.add("subgraph cluster_group_"+id);
        declaration.add("{");
        for (var c:cluster){
            DrawGraphJobNet<T> d=new DrawGraphJobNet<>(c.jobnetGraph,c.name,c.timelineLocation,toString);
            declaration.addAll(d.getClusterDeclariation());
        }
        declaration.add("}");
        return declaration;

    }
}
